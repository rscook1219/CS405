// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept> // For standard C++ exceptions

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    // Override the what() method from std::exception to return a custom error message.
    const char* what() const noexcept override {
        return "Custom Exception: Something went wrong!";
    }
};

// this function runs some application logic and throws a standard exception
bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throw a standard exception here
    throw std::runtime_error("Standard Exception: Error in do_even_more_custom_application_logic.");

    return true;
}

// This function demonstrates application logic and exception handling
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;
    try {
        // wrapping call to do_even_more_custom_application_logic().
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex) {
        // catching std::exception and printing out the message using ex.what()
        std::cerr << "Caught standard exception in custom logic: " << ex.what() << std::endl;
    }

    // Throw a custom exception derived from std::exception and catch it explictly in main
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

// this function performs division and throws an exception if denominator is zero
float divide(float num, float den)
{
    if (den == 0) {
        // Throw an exception to deal with divide by zero errors using a standard C++ defined exception
        throw std::invalid_argument("Divide by zero error!");
    }
    return (num / den);
}

// This function wraps the divide operation and handles the specific divide-by-zero error
void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    try {
        // wrapping the divide function in a try-catch block
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& ex) {
        // catching the divide-by-zero error specificially
        std::cerr << "Caught exception in division: " << ex.what() << std::endl;
    }

}

int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        // Call division logic and catch any exceptions thrown during the operation
        do_division();

        // call custom application logic and handle exceptions
        do_custom_application_logic();
    }
    catch (const CustomException& ex) {
        // catching our custom exception and printing the message
        std::cerr << "Caught custom exception: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex) {
        // catching any standard exceptions not explicitly caught earlier
        std::cerr << "Caught std::exception: " << ex.what() << std::endl;
    }
    catch (...) {
        // catch-all handler for any other unhandled exceptions
        std::cerr << "Caught an unknown exception!" << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu