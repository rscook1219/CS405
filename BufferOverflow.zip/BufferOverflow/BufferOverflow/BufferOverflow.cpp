// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // Account number that must not be changed.
    const std::string account_number = "CharlieBrown42";

    // Allocate only 20 characters for user input, but we will control the input length.
    char user_input[20];

    std::cout << "Enter a value (max 19 characters): ";

    // Using std::cin.get to safely limit input to 19 characters and leave room for the null terminator
    std::cin.get(user_input, sizeof(user_input));

    // Check if the input exceeds the buffer length
    if (std::cin.gcount() == sizeof(user_input) - 1) {
        std::cout << "Warning: Input exceeds buffer size and has been truncated." << std::endl;
    }

    // Ensure null termination for safety
    user_input[sizeof(user_input) - 1] = '\0';

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
